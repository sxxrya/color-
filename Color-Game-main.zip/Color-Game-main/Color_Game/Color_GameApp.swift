//
//  Color_GameApp.swift
//  Color_Game
//
//  Created by l on 15.08.2021.
//

import SwiftUI

@main
struct Color_GameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
