# Color Game

The purpose of the color game is to find the right color without getting distracted. It is as difficult as it is fun.

## Getting Started

### Installing

```
git clone https://github.com/Periyot/Color-Game.git
```
* After downloading the repository all you have to do is open it


## Version History

* 0.1
    * Initial Release

## License

This project is licensed under the [MIT] License - see the LICENSE.md file for details



![giphy](https://user-images.githubusercontent.com/88425310/129587218-dc4c8d0b-7cb8-40dc-ad3d-bdffa8539058.gif)


